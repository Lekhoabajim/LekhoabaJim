package model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: DigibankEntity
 *
 */
@Entity

public class DigibankEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	

	public DigibankEntity() {
		super();
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long TransactionCode;
	
	private String name;
	private String sourcePassport;
	private String destinationPassport;
	private String DestinationBank;
	private String DestationCountry;
	private String AccountNumber;
	private Double Amount;



	public Long getTransactionCode() {
		return TransactionCode;
	}
	public void setTransactionCode(Long transactionCode) {
		TransactionCode = transactionCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSourcePassport() {
		return sourcePassport;
	}
	public void setSourcePassport(String sourcePassport) {
		this.sourcePassport = sourcePassport;
	}
	public String getDestinationPassport() {
		return destinationPassport;
	}
	public void setDestinationPassport(String destinationPassport) {
		this.destinationPassport = destinationPassport;
	}
	public String getDestinationBank() {
		return DestinationBank;
	}
	public void setDestinationBank(String destinationBank) {
		DestinationBank = destinationBank;
	}
	public String getDestationCountry() {
		return DestationCountry;
	}
	public void setDestationCountry(String destationCountry) {
		DestationCountry = destationCountry;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}
	





	
	
}
